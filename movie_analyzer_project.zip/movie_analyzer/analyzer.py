"""Data-analysis layer (pandas). No Flask code here, so it is easy to test."""
import pandas as pd

REQUIRED = ["title","year","genre","director","rating","votes","budget_musd","revenue_musd","runtime"]

def load(path_or_buffer):
    df = pd.read_csv(path_or_buffer)
    missing = [c for c in REQUIRED if c not in df.columns]
    if missing:
        raise ValueError(f"CSV is missing columns: {', '.join(missing)}")
    df = df[REQUIRED].dropna(subset=["title","year","genre","rating"]).copy()
    df["year"] = df["year"].astype(int)
    df["profit_musd"] = (df["revenue_musd"] - df["budget_musd"]).round(1)
    return df

def filter_df(df, genre="All", year_from=None, year_to=None, q=""):
    if genre and genre != "All":
        df = df[df["genre"] == genre]
    if year_from: df = df[df["year"] >= int(year_from)]
    if year_to:   df = df[df["year"] <= int(year_to)]
    if q:         df = df[df["title"].str.contains(q, case=False, na=False)]
    return df

def summary(df):
    if df.empty:
        return {"count":0,"avg_rating":0,"total_revenue":0,"avg_budget":0}
    return {"count": int(len(df)),
            "avg_rating": round(df["rating"].mean(), 2),
            "total_revenue": round(df["revenue_musd"].sum(), 1),
            "avg_budget": round(df["budget_musd"].mean(), 1)}

def analyse(df):
    g = df.groupby("genre")
    per_year = df.groupby("year").agg(avg_rating=("rating","mean"), revenue=("revenue_musd","sum")).round(2)
    top = df.sort_values(["rating","votes"], ascending=False).head(10)
    best_dir = (df.groupby("director").filter(lambda x: len(x) >= 3)
                  .groupby("director")["rating"].mean().round(2).sort_values(ascending=False).head(5))
    corr = df[["rating","budget_musd","revenue_musd","runtime"]].corr().round(2) if len(df) > 2 else None
    return {
        "summary": summary(df),
        "genre_count": g.size().sort_values(ascending=False).to_dict(),
        "genre_rating": g["rating"].mean().round(2).sort_values(ascending=False).to_dict(),
        "years": list(map(int, per_year.index)),
        "year_rating": per_year["avg_rating"].tolist(),
        "year_revenue": per_year["revenue"].tolist(),
        "scatter": df[["budget_musd","revenue_musd"]].rename(columns={"budget_musd":"x","revenue_musd":"y"}).to_dict("records"),
        "top": top[["title","year","genre","director","rating","revenue_musd"]].to_dict("records"),
        "best_directors": best_dir.to_dict(),
        "corr_budget_revenue": float(corr.loc["budget_musd","revenue_musd"]) if corr is not None else None,
    }
