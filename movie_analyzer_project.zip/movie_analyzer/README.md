# Movie Data Analyzer (Flask + pandas)
## Run
    pip install -r requirements.txt
    python app.py
Open http://127.0.0.1:5000
## Files
- app.py – Flask routes (/, /api/analyse, /api/upload)
- analyzer.py – pandas analysis logic
- generate_data.py – builds sample data/movies.csv (synthetic)
- templates/index.html – dashboard (Chart.js)
## Using real data
Upload any CSV with columns: title, year, genre, director, rating, votes, budget_musd, revenue_musd, runtime
