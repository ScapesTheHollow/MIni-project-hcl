"""Creates a synthetic sample dataset (data/movies.csv). Replace with a real
Kaggle/TMDB CSV that has the same columns to analyse real movies."""
import random, csv
random.seed(7)
genres = ["Action","Comedy","Drama","Horror","Sci-Fi","Romance","Thriller","Animation"]
directors = ["A. Rao","B. Khan","C. Mehta","D. Smith","E. Lopez","F. Chen","G. Singh","H. Brown","I. Kapoor","J. Wilson"]
words1 = ["Dark","Last","Silent","Golden","Lost","Hidden","Rising","Broken","Eternal","Crimson","Midnight","Wild"]
words2 = ["Horizon","Empire","Promise","Shadow","Journey","Legacy","Storm","Dream","Kingdom","Secret","Echo","Frontier"]
base = {"Action":(120,6.3),"Comedy":(50,6.2),"Drama":(35,7.0),"Horror":(25,5.9),
        "Sci-Fi":(140,6.6),"Romance":(40,6.4),"Thriller":(60,6.5),"Animation":(110,7.0)}
rows, seen = [], set()
while len(rows) < 300:
    t = f"{random.choice(words1)} {random.choice(words2)}"
    if t in seen: t += f" {random.randint(2,4)}"
    if t in seen: continue
    seen.add(t)
    g = random.choice(genres); b, r = base[g]
    budget = round(max(2, random.gauss(b, b*0.4)), 1)
    rating = round(min(9.5, max(2.5, random.gauss(r, 0.9))), 1)
    revenue = round(max(0.5, budget * random.uniform(0.3, 1.5) * (1 + (rating-6)*0.5) * random.uniform(0.6, 2.2)), 1)
    rows.append([t, random.randint(2000, 2024), g, random.choice(directors), rating,
                 random.randint(5000, 900000), budget, revenue, random.randint(80, 175)])
with open("data/movies.csv", "w", newline="") as f:
    w = csv.writer(f)
    w.writerow(["title","year","genre","director","rating","votes","budget_musd","revenue_musd","runtime"])
    w.writerows(rows)
print("rows:", len(rows))
