"""Flask web app: serves the dashboard and a JSON API backed by analyzer.py."""
import io
from flask import Flask, render_template, request, jsonify
import analyzer

app = Flask(__name__)
app.config["MAX_CONTENT_LENGTH"] = 5 * 1024 * 1024   # 5 MB upload limit
DF = analyzer.load("data/movies.csv")                  # active dataset (in memory)

@app.route("/")
def index():
    return render_template("index.html", genres=sorted(DF["genre"].unique()),
                           ymin=int(DF["year"].min()), ymax=int(DF["year"].max()))

@app.route("/api/analyse")
def api_analyse():
    d = analyzer.filter_df(DF, request.args.get("genre","All"),
                           request.args.get("year_from"), request.args.get("year_to"),
                           request.args.get("q",""))
    return jsonify(analyzer.analyse(d) if not d.empty else {"summary": analyzer.summary(d), "empty": True})

@app.route("/api/upload", methods=["POST"])
def api_upload():
    global DF
    f = request.files.get("file")
    if not f or not f.filename.lower().endswith(".csv"):
        return jsonify(error="Please upload a .csv file"), 400
    try:
        DF = analyzer.load(io.BytesIO(f.read()))
    except Exception as e:
        return jsonify(error=str(e)), 400
    return jsonify(ok=True, rows=len(DF))

if __name__ == "__main__":
    app.run(debug=True)
